# -*- coding: utf-8 -*-

from . import models
from . import inherit_product_template
from . import sale_order_line
from . import product_product
